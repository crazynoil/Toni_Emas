# Changelog

### 0.0.3 (Dec 17, 2014)

- Add new options: "autoStore", "maxAge".
- Add new method: "serialize".


### 0.0.2 (Dec 14, 2014)

- Turns to use single quotation marks.
- Ignores file inputs (#1).


### 0.0.1 (Nov 30, 2014)

- Supports options: "key", "local", "session"
- Supports methods: "getCache", "getCaches", "setCache", "setCaches", "removeCache" "removeCaches", "outputCache", "store", "clear", "destroy"
